<?php
require_once("layout/navbar.php");

?>
  <!-- Page Content -->
  <div  class="container">
    <br/>
    <!-- Page Heading/Breadcrumbs -->
    <? $atual = $videoAtual;?>
    <h1 class="mt-4 mb-3">
    <div class="row">
      <small class="tituloj" style="color:#244c74"> 
      <br/>JORNADA DO INVESTIDOR
        <h4 class="tituloj2" style="color:#244c74;"><? echo $atual['titulo']; ?></h4>
      </small>
</div>
    </h1>

    <!-- /.row -->
    <br/>
    <div class="row">
    <div class="col-9">
        <div class="row" id="body-video"  style="position:relative;left:-12%;width:118%;height:38em;box-shadow: 0 0 0.5em gray;">
              <div class="body-video"   >
                  <a href="videoaula2">              
                  <? echo  $atual['nome']; ?>
                  </a>
              </div>
          </div>
      </div>
      <div class="col-3" id="videoaula">
          <h4 class="d-flex justify-content-center" >Videoaulas</h4>
          <div style="position:relative;height:600px;width:117%;" class="overflow-auto">
          <div style="position:relative;width:90%;display: inline-block;" class="row">

          <? $ctd = count($videos); ?>
          <? for ($i=0; $i <= $ctd; $i++) {
              if(isset($videos[$i]['imagem'])){                              
            ?>
              <a id="hovervid" href="proximoVideo?id=<? echo $videos[$i]['id'];?>">
                <img class="d-block w-10" style="position:relative;margin:3px;" width="290px;" height="250px;" src="<? echo $videos[$i]['imagem'];?>" alt="Primeiro Slide">
              </a>  

            <?    }    
          } ?>
        </div>  
        </div>

        </div>
      </div>
          <div style="position:relative;width:100%;"  >

            <div style="position:relative;width:100%;font-size:15px;top:2em;"  >
              <h3><? echo $atual['titulo']; ?></h3>
              <p  style="position:relative;width:70%;font-size:18px;top:2em;"><? echo $atual['descricao']; ?></p>
            </div>
        </div>
        </div>
        </div>

        <br/>
        <br/>
        <h3 class="my-4" style="border-top: 1px solid #244c74; padding:20px;"></h3>

          <div id="comentarios" style="background-color: white!important;" class="col-md-8">

          <form action="comentarVideo" style="position:relative;width:100%;" method="post">
            <div class="form-group form-check">
            <i id="iconc" style="position:relative;font-size:25px;left:5%;top:0.8em;color:#043c75;width:1%;" class="fa fa-user-circle-o"> </i> 
              <input style="display:none;" id="inputcoment" type="text" class="form-control" name="id_video" placeholder="Comentar" value="<? if (isset($_GET['id'])){ echo $_GET['id']; } else { echo '1'; } ?>" aria-describedby="basic-addon1">

              
              <input style="position:relative;left:9%;top:-0.8em;color:#043c75;width:80%;" id="inputcoment" type="text" class="form-control" name="comentario" placeholder="Comentar" aria-describedby="basic-addon1">
            </div>

              <button class="btn btn-light" id="buttonc" type="submit"  style="position:relative;left:90%;top:-4em;border:0.5px solid  gray!important;border-radius:50%;background-color:white;color:#043c75;width:3.5%;"><i style="position:relative;left:-0.5em;width:10%;color:blue;" class="fa fa-paper-plane" aria-hidden="true"></i></button>          
          </form>
          <? if ($comentarios != "Nenhum comentário"): ?>          
          <?php 
            foreach($comentarios as $coment): ?>
            <div style="position:relative;margin:0;border:none;overflow:auto;"class="card mb-4">
              <div  style="position:relative;border-bottom:1px solid rgba(0,0,0,.125);background-color:white; " >
                  <div  style="position:relative;height:100%;border:none" >
                   <img src="/perfil/<? echo $coment->foto ?>" id="fotocoment" class="rounded-circle" alt="Avatar" style="position:relative;left:3%;top:1.5em;width:4.5%;height:2.5em;">
                   <p id="nomep" style="position:relative;top:-1em;left:10%;font-size:12px;color:#043c75;width:60%;"><? echo $coment->nome." ".$coment->sobrenome; ?> </p>
                   <p id="nomep" style="position:relative;top:-2em;left:10%;font-size:12px;color:gray;width:60%;"><? 
                    $hoje = date('d-m-Y', time());               
                    $date = (new DateTime($coment->data));         
                    $data = $date->format("d-m-Y") ;
                    $ontem = date('d-m-Y',strtotime("-1 days"));
                    if($hoje == $data){
                      $date = (new DateTime($coment->data));
                        echo "hoje às ".$date->format("H:i");          
                    }
                    if($data ==  $ontem){
                      echo "Ontem às ".$date->format("H:i");          
                    }
                    if($data !=  $ontem && $data !=  $hoje ) {
                      
                      echo $data;
                    } ?>
                    </p>
                   <p  id="comentp" style="position:relative;top:-2.5em;left:10%;font-size:15px;color:black;width:90%;"> <? echo $coment->comentario;?><br/>
                   <? if ($_SESSION['id'] == $coment->id_user): ?>
                     <a href="deletarComentarioVideo?id=<? echo $coment->id_comentario ?>&id_video=<? if (isset($_GET['id'])){ echo $_GET['id']; } else { echo '1'; }  ?>"   style="color:#385898;text-decoration:none;font-size:10px;"><i class="fa fa-remove" style="color:#385898;font-size:10px;" aria-hidden="true"></i> &nbsp Deletar</a>  &nbsp  &nbsp
                     <a  data-toggle="modal" data-target="#exampleModal2" data-whatever="<? echo  $coment->comentario."-".$coment->id_comentario; ?>"  href="#" style="color:#385898;text-decoration:none;font-size:10px;"><i class="fa fa-edit" style="color:#385898;font-size:10px;" aria-hidden="true"></i> &nbsp Editar</a>
                   <? endif ?> </p>


                </div>
                </div>
                </div>

            <? endforeach ?>
        <?else: ?>
          <div class="shadow-none p-3 mb-5 bg-light rounded">Nenhum comentário</div>
        <? endif ?>      
        </div>

        <br/>
        <br/>


    </div>
    <!-- /.row -->
<br/>
  <!-- /.container -->
<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Editar Comentário</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="alterarComentarioVideo">
          <div class="form-group">
            <label for="message-text" class="col-form-label">Mensagem:</label>
            <textarea class="form-control" name="comentario"    id="message-text"></textarea>
          </div>
          <div class="form-group">
            <input class="form-control" style="display:none;" id="message-text" name="id_comentario" type="text">
          </div>
          <input style="display:none;" value="<? if (isset($_GET['id'])){ echo $_GET['id']; } else { echo '1'; }  ?>" name="id_video" type="text">

          <button type="submit" class="btn btn-success" >Salvar</button>
        </form>
      </div>
      <div class="modal-footer">
        <a class="btn btn-dark" href="#" role="button" data-dismiss="modal">Fechar</a>
      </div>
    </div>
  </div>
</div>




<script>

$('#exampleModal2').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Botão que acionou o modal
  var recipient = button.data('whatever') // Extrai informação dos atributos data-*
  resultado = recipient.split("-");
  var msg = resultado[0];
  var id = resultado[1]; // Extrai informação dos atributos data-*
  // Se necessário, você pode iniciar uma requisição AJAX aqui e, então, fazer a atualização em um callback.
  // Atualiza o conteúdo do modal. Nós vamos usar jQuery, aqui. No entanto, você poderia usar uma biblioteca de data binding ou outros métodos.
  var modal = $(this)
  modal.find('.modal-body input.form-control').val(id)
  modal.find('.modal-body textarea').val(msg)
})
</script>





<?php
require_once("layout/footer.php");

?>