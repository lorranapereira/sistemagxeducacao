<?php
require_once("layout/navbar.php");  
?>
  <!-- Page Content -->
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    </br>
    <h1 class="mt-4 mb-3" style="color:#244c74; text-align:center;   font-family: Raleway, sans-serif;border-bottom: 2px solid #244c74; ">
    <strong> Gx Investimento</strong>
    </h1>
    </br>

    <?php foreach ($curso as $row): ?> 
    <div class="row">
    
        <!-- Post Content Column -->
        <div class="col-lg-8"  style="  font-family: Raleway, sans-serif;">
          <!-- Preview Image -->
          <img class="img-fluid rounded" src="/css/fundocad.png" alt="">
    
    
          <hr>
    
          <!-- Post Content -->
          <p class="lead"><? echo $row->info; ?></p>
          <hr>
    
          <p> <strong>OBJETIVOS: </strong></p>
          <ul>
            <li> Desenvolver uma compreensão a respeito;</li>
            <li> Fornecer instrumental analítico em gráficos;</li>
            <li> Estimular a reflexão sobre problemas e dilemas relacionados ao investimentos.</li>
          </ul>
          <hr>
            <p> <strong> RECURSOS UTILIZADOS  </strong></p>
    
                <ul>
                    <li>
                       Videoaula 
                    </li>
                    <li>
                       Computador 
                    </li>
                    <li>
                       Apostila 
                    </li>
                    <li>
                      Pincel para quadro branco 
                    </li>
                  </ul>
    
          <hr>
          <p> <strong>ANÁLISE TÉCNICA</strong> </p>
          <p>A análise técnica procura determinar o melhor
              momento para a compra e a venda de ativos.
              Seu principal objetivo é mensurar o comportamento
              dos preços através da utilização de gráficos
              como principal ferramenta, aliados a fórmulas
              matemáticas e cálculos estatísticos. Dessa forma,
              permite ao investidor maximizar seus lucros e
              minimizar os riscos, por meio de previsões de preços
              futuros das ações, pois está baseada no fato
              de que todos os fatores podem influir no preço
              de um determinado ativo.</p>
          <p>A análise técnica é muito usada em operações
              em que o investidor visa obter ganhos em curto
              espaço de tempo (day trade), onde os gráficos
              também podem ser usados para operações mais
              longas na Bolsa, bastando calibrar seus indicadores. </p>
          <p>Com algumas técnicas simples
                de gerenciamento de risco, você poderá limitar
                o tamanho da perda e prolongar os ganhos
                o máximo possível. Independentemente
                da estratégia a ser adotada para lucratividade em
                seus investimentos, a análise técnica é fundamental
                para a formação de investidores mais conscientes de
                suas possibilidades, mais seguros de suas ações e
                sensatos em suas operações.</p>
          <br/>
          <br/>
          </div>
          <hr>
    
          <!-- Comments Form -->
     <!--     <div class="card my-4">
            <h5 class="card-header">Leave a Comment:</h5>
            <div class="card-body">
              <form>
                <div class="form-group">
                  <textarea class="form-control" rows="3"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
              </form>
            </div>
          </div>
    
          <!-- Single Comment 
          <div class="media mb-4">
            <img class="d-flex mr-3 rounded-circle" src="http://placehold.it/50x50" alt="">
            <div class="media-body">
              <h5 class="mt-0">Commenter Name</h5>
              Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
            </div>
          </div>
    
          <!-- Comment with nested comments 
          <div class="media mb-4">
            <img class="d-flex mr-3 rounded-circle" src="http://placehold.it/50x50" alt="">
            <div class="media-body">
              <h5 class="mt-0">Commenter Name</h5>
              Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
    
              <div class="media mt-4">
                <img class="d-flex mr-3 rounded-circle" src="http://placehold.it/50x50" alt="">
                <div class="media-body">
                  <h5 class="mt-0">Commenter Name</h5>
                  Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
                </div>
              </div>
    
              <div class="media mt-4">
                <img class="d-flex mr-3 rounded-circle" src="http://placehold.it/50x50" alt="">
                <div class="media-body">
                  <h5 class="mt-0">Commenter Name</h5>
                  Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
                </div>
              </div>
    
            </div>
          </div>
    
        </div>
    
        <!-- Sidebar Widgets Column -->
        <div class="col-md-4">
          <!-- Search Widget -->
          <div class="card mb-4">
            <h5 class="card-header">Garanta sua vaga!</h5>
            <div class="card-body">
              <div class="input-group">
                <span class="input-group-btn">
                  <a type="button" href="https://materiais.gxinveste.com.br/agradecimento-jornada" class="btn btn-secondary" id="logar" style="background-color:blue;"type="button">Comprar!
                  <i class="fa fa-shopping-cart" style="font-size:20px;color:white"></i>
                 </a>
                </span>
              </div>
            </div>
          </div>
          <!-- Categories Widget -->
          <div class="card my-4">
            <h5 class="card-header">METODOLOGIA</h5>
            <div class="card-body">
              <div class="row">
                <div class="col-lg-12">
                  <ul class="list-unstyled mb-0">
                    <li>
                      <p> Videoaula de nivelamento <i class="fa fa-check" style="color:green;" aria-hidden="true"></i></p>
                    </li>
                    <li>
                      <p> Aula expositiva <i class="fa fa-check" style="color:green;" aria-hidden="true"></i></p>
                    </li>
                    <li>
                      <p> Aula experimental em horário de funcionamento da bolsa de valores <i class="fa fa-check" style="color:green;" aria-hidden="true"></i></p>
                    </li>
                    <li>
                      <p>Educação continuada <i class="fa fa-check" style="color:green;" aria-hidden="true"></i></p>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
    
          <!-- Side Widget -->
    
        </div>
    
      </div>
      <!-- /.row -->
      <?php endforeach ?>
    
    
    </div>
    

  <!-- /.container -->
  <?
    require_once("layout/footer.php");
  ?>