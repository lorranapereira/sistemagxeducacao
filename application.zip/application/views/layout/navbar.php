<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Gx educação</title>
  <link href="https://fonts.googleapis.com/css?family=Playfair+Display&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Rubik:500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Playfair+Display&display=swap" rel="stylesheet">
  <link rel="shortcut icon" href="/css/favicon.ico" type="image/x-icon">
  <link href="https://fonts.googleapis.com/css?family=Heebo&display=swap" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css?family=Heebo|Jomolhari&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Heebo|Jomolhari|Playfair+Display&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
  <link rel="stylesheet" href="/css/style.css" >
  <link href="/css2/style.css" rel="stylesheet">


  <style>
      body {
        padding-top: 56px;
        overflow-x: hidden;    

      }
      video::-internal-media-controls-download-button {
        display:none;
      }

      video::-webkit-media-controls-enclosure {
        overflow:hidden;
      }

      video::-webkit-media-controls-panel {
        width: calc(100% + 30px); /* Adjust as needed */
      }
      @media (max-width: 992px) {
          #body {
            position: absolute;
            background-image:url(/css/curso2.jpg) !important;
            background-attachment: fixed!important;
            background-position: center!important; 
            
          }

        }

  </style>
</head>

<body style="background-color: #e0dfef;">
<? if(!isset($_SESSION['nome'])){
  header("Location:http://localhost/index.php/Control");
} ?>
  <!-- Navigation -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light fixed-top"  style="background-color:white!important;">
    <div class="container">
    <img class="logo" width="20%;" src="/css/gxeduca.png" alt="">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="/index.php/Control/inicial">Página inicial</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="text-decoration:none" href="/index.php/Control/cursosgx">Cursos</a>
          </li>
         <? if($_SESSION['email'] == "vinicius.teixeira@gxinvestimentos"):?>

          <li class="nav-item">
            <a class="nav-link" href="/index.php/Control/todosvideos"> Administrar</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/index.php/Control/cadastrarcurso"> Cadastrar curso</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/index.php/Control/uparvideo">Submeter vídeo</a>
          </li>
          <? endif ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Conta
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
              <a class="dropdown-item" href="/index.php/Control/minhaconta">Minha conta</a>
              <a class="dropdown-item" href="/index.php/Control/sair">Sair</a>

            </div>
          </li>

      </div>
    </div>
  </nav>

  <!-- Page Content -->

      